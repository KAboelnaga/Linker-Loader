Please download the required import (tkinter and ttk most probably) and then configure and run the file GUI2,
you should enter the relocation of each program (PROGA,PROGB) then the loader will appear in gui. i have
submitted all the files i worked on (the sequential storing isn't 100% correct) object code 2 and external table 2 are
linked to the store each with relocation file (the full correct file) HTE is the input file to both python files
Modifications file include the m records of both proga and progb combined
........................................................................................................................
						
						summary: 

1)download imports
2)run GUI2 file
3)check HTE,Object Code 2, External Table 2, and the GUI for checking the input